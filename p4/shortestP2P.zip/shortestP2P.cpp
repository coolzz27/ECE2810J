#include "shortestP2P.hpp"

using namespace std;

void ShortestP2P::readGraph() {
    unsigned int v, e;
    cin >> v >> e;
    dist = vector<vector<int>>(v, vector<int>(v, INF));
    for (unsigned int i = 0; i < e; i++) {
        unsigned int src, dest;
        int weight;
        cin >> src >> dest >> weight;
        dist[src][dest] = weight;
    }
    for (unsigned int i = 0; i < v; i++) {
        dist[i][i] = 0;
    }
    detect_negative_cycle();
}

void ShortestP2P::distance(unsigned int A, unsigned int B) {
    if (dist[A][B] == INF) {
        cout << "INF" << endl;
    } else {
        cout << dist[A][B] << endl;
    }
}

void ShortestP2P::detect_negative_cycle() {
    for (unsigned int k = 0; k < dist.size(); k++) {
        for (unsigned int i = 0; i < dist.size(); i++) {
            for (unsigned int j = 0; j < dist.size(); j++) {
                if (dist[i][k] != INF && dist[k][j] != INF && dist[i][k] + dist[k][j] < dist[i][j])
                {
                    // cout << "dist" << i << " " << j << "updated from " << dist[i][j] << " to "
                    //  << dist[i][k] + dist[k][j] << endl;
                    dist[i][j] = dist[i][k] + dist[k][j];
                }
            }
        }
    }
    for (unsigned int i = 0; i < dist.size(); i++) {
        if (dist[i][i] < 0) {
            cout << "Invalid graph. Exiting." << endl;
            exit(0);
        }
    }
}